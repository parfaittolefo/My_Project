
#ifndef A_LL_H_H
#define A_LL_H_H
#include <QScreen>
#include <QFont>
#include <QSqlQuery>
#include <QSqlDatabase>
#include <QApplication>
#include <QMainWindow>
#include <QtWidgets>
#include <hireimg.h>
#include "hircare_3.h"
#include "image.h"
#include "login_1.h"
#include "care_state.h"
#include <QStackedWidget>

//QStackedWidget* MysTackedWidget;

#endif // A_LL_H_H
