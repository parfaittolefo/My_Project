#ifndef HIREIMG_H
#define HIREIMG_H

#include <QMainWindow>

class HireImg : public QMainWindow
{
    Q_OBJECT
public:
    explicit HireImg(QWidget *parent = nullptr);

signals:

};

#endif // HIREIMG_H
