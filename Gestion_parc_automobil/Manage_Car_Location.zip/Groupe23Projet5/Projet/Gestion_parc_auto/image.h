#ifndef IMAGE_H
#define IMAGE_H
#include <QMainWindow>

class Image : public QMainWindow
{
public:
    Image();

};

#endif // IMAGE_H
