#include "multiplication_class.h"

#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    Multiplication_class w;
    w.show();
    return a.exec();
}
